import { BrowserRouter, Routes, Route } from "react-router-dom";
import Header from './Components/Header';
import Nav from './Components/Nav';
import Footer from './Components/Footer';
import Inicio from './Pages/Inicio';
import Materiales from './Pages/Materiales';
import Login from './Pages/Login';
import Register from './Pages/Register';
import Productos from "./Pages/Productos";
import cardProducto from "./components/cardProducto";


function App() {
  return (
    <BrowserRouter>
      <Header />
      <Nav />
      <Routes>
        <Route path="/" element={<Inicio />} />
         <Route path="/productos" element={<Productos/>} />
        <Route path="/materiales" element={<Materiales />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
      </Routes>
      <Footer />
    </BrowserRouter>
  );
}

export default App;