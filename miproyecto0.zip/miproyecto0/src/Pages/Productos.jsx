import Header from "../components/Header";
import Footer from "../components/Footer";
import Nav from "../components/Nav";
import CardProducto from "../components/CardProducto";
import { useEffect, useState } from "react";

function Product() {
    const [productos, setProductos] = useState([]);

    async function cargarProducto() {
        try {
            const respuesta = await fetch("https://fakestoreapi.com/products")
            const data = await respuesta.json();

            const ropa = data.filter(producto =>        
                producto.category === "men's clothing" ||
                producto.category === "women's clothing"
            );

            setProductos(ropa);
        } catch (error) {
            console.log(error);
        }
    }

    useEffect(() => {
        cargarProducto();
    }, []);

    return (
        <>
            <main className="container py-5">
                <h2 className="text-center mb-4">
                    Catálogo de Ropa
                </h2>
                <div id="contenedor-productos" className="row g-4">
                    {productos.map(producto => (
                        <CardProducto
                            key={producto.id}
                            imagen={producto.image}
                            titulo={producto.title}
                            descripcion={producto.description.substring(0, 80)}
                        />
                    ))}
                </div>
            </main>
            
        </>
    );
}

export default Product;