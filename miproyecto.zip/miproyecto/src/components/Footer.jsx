function Footer() {
  return (
    <footer>
      <p>© 2026 Tienda Fashion</p>
    </footer>
  )
}

export default Footer