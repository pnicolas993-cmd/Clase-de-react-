function Nav() {
    return (
    <nav>

        <div className="nav-left">
            <a href="#">Inicio</a>

            <a href="vistas/products.html">Productos</a>

            <a href="vistas/materiales.html">Nuestros Materiales</a>
            
            <a href="#">Contacto</a>
        </div>
    
        <div className="nav-right">
    
            <a href="vistas/login.html"
               className="btn-login">
               Login
            </a>
    
            <a href="vistas/register.html"
               className="btn-register">
               Registro
            </a>
    
        </div>
    
    </nav>
    )
}

export default Nav