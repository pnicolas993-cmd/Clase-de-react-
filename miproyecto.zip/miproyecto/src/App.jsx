import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from './assets/vite.svg'
import heroImg from './assets/hero.png'
import Header from './components/Header'
import Nav from './components/Nav'
import Footer from './components/Footer'
import './style/stylesppal.css'

function App() {

  return (
    <>
      <Header />
      <Nav />


      <Footer />


      

    </>
  )
}

export default App
