function Register() {
  return (
    <>  
          <main className="contenedor-formulario">

              <form className="formulario">

                  <h2>Crear Cuenta</h2>

                  <div className="grupo-input">

                      <label>Nombre completo</label>

                      <input type="text"
                          placeholder="Ingrese su nombre"/>

                  </div>


                  <div className="grupo-input">

                      <label>Correo electrónico</label>

                      <input type="email"
                          placeholder="Ingrese su correo"/>

                  </div>


                  <div className="grupo-input">

                      <label>Contraseña</label>

                      <input type="password"
                          placeholder="Ingrese su contraseña"/>

                  </div>


                  <div className="grupo-input">

                      <label>Confirmar contraseña</label>

                      <input type="password"
                          placeholder="Confirme contraseña"/>

                  </div>

                  <button type="submit">
                      Registrarse
                  </button>

              </form>

          </main>
    
    
    </>
  )
}

export default Register;